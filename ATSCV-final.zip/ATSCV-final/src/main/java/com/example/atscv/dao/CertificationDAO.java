package com.example.atscv.dao;

import com.example.atscv.model.Certification;
import com.example.atscv.util.DBConnection;
import java.sql.*;
import java.util.*;

public class CertificationDAO {
    public boolean saveCertification(Certification c) {
        String sql = "INSERT INTO certifications (resume_id, certificate_name, issuing_organization, issue_date, expiry_date, credential_id, credential_url) VALUES (?,?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, c.getResumeId()); ps.setString(2, c.getCertificateName());
            ps.setString(3, c.getIssuingOrganization()); ps.setDate(4, c.getIssueDate());
            ps.setDate(5, c.getExpiryDate()); ps.setString(6, c.getCredentialId());
            ps.setString(7, c.getCredentialUrl());
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }
    public List<Certification> getCertificationsByResumeId(int resumeId) {
        List<Certification> list = new ArrayList<>();
        String sql = "SELECT * FROM certifications WHERE resume_id = ? ORDER BY issue_date DESC";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, resumeId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Certification cert = new Certification();
                    cert.setId(rs.getInt("id")); cert.setResumeId(rs.getInt("resume_id"));
                    cert.setCertificateName(rs.getString("certificate_name")); cert.setIssuingOrganization(rs.getString("issuing_organization"));
                    cert.setIssueDate(rs.getDate("issue_date")); cert.setExpiryDate(rs.getDate("expiry_date"));
                    cert.setCredentialId(rs.getString("credential_id")); cert.setCredentialUrl(rs.getString("credential_url"));
                    list.add(cert);
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}
