package com.example.atscv.dao;

import com.example.atscv.model.Education;
import com.example.atscv.util.DBConnection;
import java.sql.*;
import java.util.*;

public class EducationDAO {
    public boolean saveEducation(Education e) {
        String sql = "INSERT INTO education (resume_id, institution_name, qualification, field_of_study, start_date, end_date, grade, description) VALUES (?,?,?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, e.getResumeId()); ps.setString(2, e.getInstitutionName());
            ps.setString(3, e.getQualification()); ps.setString(4, e.getFieldOfStudy());
            ps.setDate(5, e.getStartDate()); ps.setDate(6, e.getEndDate());
            ps.setString(7, e.getGrade()); ps.setString(8, e.getDescription());
            return ps.executeUpdate() > 0;
        } catch (Exception ex) { ex.printStackTrace(); return false; }
    }
    public List<Education> getEducationByResumeId(int resumeId) {
        List<Education> list = new ArrayList<>();
        String sql = "SELECT * FROM education WHERE resume_id = ? ORDER BY start_date DESC";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, resumeId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Education ed = new Education();
                    ed.setId(rs.getInt("id")); ed.setResumeId(rs.getInt("resume_id"));
                    ed.setInstitutionName(rs.getString("institution_name")); ed.setQualification(rs.getString("qualification"));
                    ed.setFieldOfStudy(rs.getString("field_of_study")); ed.setStartDate(rs.getDate("start_date"));
                    ed.setEndDate(rs.getDate("end_date")); ed.setGrade(rs.getString("grade"));
                    ed.setDescription(rs.getString("description")); list.add(ed);
                }
            }
        } catch (Exception ex) { ex.printStackTrace(); }
        return list;
    }
}
