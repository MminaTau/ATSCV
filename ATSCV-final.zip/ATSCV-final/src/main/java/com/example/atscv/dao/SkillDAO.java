package com.example.atscv.dao;

import com.example.atscv.model.Skill;
import com.example.atscv.util.DBConnection;
import java.sql.*;
import java.util.*;

public class SkillDAO {
    public boolean saveSkill(Skill s) {
        String sql = "INSERT INTO skills (resume_id, skill_name, skill_category, proficiency_level) VALUES (?,?,?,?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, s.getResumeId()); ps.setString(2, s.getSkillName());
            ps.setString(3, s.getSkillCategory()); ps.setString(4, s.getProficiencyLevel());
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }
    public List<Skill> getSkillsByResumeId(int resumeId) {
        List<Skill> list = new ArrayList<>();
        String sql = "SELECT * FROM skills WHERE resume_id = ? ORDER BY skill_category, skill_name";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, resumeId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Skill sk = new Skill();
                    sk.setId(rs.getInt("id")); sk.setResumeId(rs.getInt("resume_id"));
                    sk.setSkillName(rs.getString("skill_name")); sk.setSkillCategory(rs.getString("skill_category"));
                    sk.setProficiencyLevel(rs.getString("proficiency_level")); list.add(sk);
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}
