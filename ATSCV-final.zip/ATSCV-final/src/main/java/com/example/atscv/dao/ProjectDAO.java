package com.example.atscv.dao;

import com.example.atscv.model.Project;
import com.example.atscv.util.DBConnection;
import java.sql.*;
import java.util.*;

public class ProjectDAO {
    public boolean saveProject(Project p) {
        String sql = "INSERT INTO projects (resume_id, project_title, technologies_used, project_link, description) VALUES (?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, p.getResumeId()); ps.setString(2, p.getProjectTitle());
            ps.setString(3, p.getTechnologiesUsed()); ps.setString(4, p.getProjectLink());
            ps.setString(5, p.getDescription());
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }
    public List<Project> getProjectsByResumeId(int resumeId) {
        List<Project> list = new ArrayList<>();
        String sql = "SELECT * FROM projects WHERE resume_id = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, resumeId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Project pr = new Project();
                    pr.setId(rs.getInt("id")); pr.setResumeId(rs.getInt("resume_id"));
                    pr.setProjectTitle(rs.getString("project_title")); pr.setTechnologiesUsed(rs.getString("technologies_used"));
                    pr.setProjectLink(rs.getString("project_link")); pr.setDescription(rs.getString("description"));
                    list.add(pr);
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}
