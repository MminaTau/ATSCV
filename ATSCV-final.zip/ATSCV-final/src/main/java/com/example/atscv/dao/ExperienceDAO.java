package com.example.atscv.dao;

import com.example.atscv.model.Experience;
import com.example.atscv.util.DBConnection;
import java.sql.*;
import java.util.*;

public class ExperienceDAO {
    public boolean saveExperience(Experience e) {
        String sql = "INSERT INTO experience (resume_id, company_name, job_title, location, start_date, end_date, currently_working, responsibilities, achievements) VALUES (?,?,?,?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, e.getResumeId()); ps.setString(2, e.getCompanyName());
            ps.setString(3, e.getJobTitle()); ps.setString(4, e.getLocation());
            ps.setDate(5, e.getStartDate()); ps.setDate(6, e.getEndDate());
            ps.setBoolean(7, e.isCurrentlyWorking()); ps.setString(8, e.getResponsibilities());
            ps.setString(9, e.getAchievements());
            return ps.executeUpdate() > 0;
        } catch (Exception ex) { ex.printStackTrace(); return false; }
    }
    public List<Experience> getExperienceByResumeId(int resumeId) {
        List<Experience> list = new ArrayList<>();
        String sql = "SELECT * FROM experience WHERE resume_id = ? ORDER BY start_date DESC";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, resumeId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Experience ex = new Experience();
                    ex.setId(rs.getInt("id")); ex.setResumeId(rs.getInt("resume_id"));
                    ex.setCompanyName(rs.getString("company_name")); ex.setJobTitle(rs.getString("job_title"));
                    ex.setLocation(rs.getString("location")); ex.setStartDate(rs.getDate("start_date"));
                    ex.setEndDate(rs.getDate("end_date")); ex.setCurrentlyWorking(rs.getBoolean("currently_working"));
                    ex.setResponsibilities(rs.getString("responsibilities")); ex.setAchievements(rs.getString("achievements"));
                    list.add(ex);
                }
            }
        } catch (Exception ex) { ex.printStackTrace(); }
        return list;
    }
}
