package com.example.atscv.servlet;

import com.example.atscv.dao.*;
import com.example.atscv.model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/viewResume")
public class ViewResumeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp"); return;
        }
        User user = (User) session.getAttribute("user");
        String idStr = request.getParameter("id");
        if (idStr == null) { response.sendRedirect("myResumes"); return; }
        try {
            int resumeId = Integer.parseInt(idStr);
            ResumeDAO resumeDAO = new ResumeDAO();
            Resume resume = resumeDAO.getResumeById(resumeId);
            if (resume == null || resume.getUserId() != user.getId()) {
                response.sendRedirect("myResumes"); return;
            }
            request.setAttribute("resume", resume);
            request.setAttribute("educationList", new EducationDAO().getEducationByResumeId(resumeId));
            request.setAttribute("experienceList", new ExperienceDAO().getExperienceByResumeId(resumeId));
            request.setAttribute("skillList", new SkillDAO().getSkillsByResumeId(resumeId));
            request.setAttribute("projectList", new ProjectDAO().getProjectsByResumeId(resumeId));
            request.setAttribute("certificationList", new CertificationDAO().getCertificationsByResumeId(resumeId));
            request.getRequestDispatcher("viewResume.jsp").forward(request, response);
        } catch (NumberFormatException e) { response.sendRedirect("myResumes"); }
    }
}
