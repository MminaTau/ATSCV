package com.example.atscv.dao;

import com.example.atscv.model.Resume;
import com.example.atscv.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ResumeDAO {

    public int saveResume(Resume resume) {
        int generatedId = 0;
        String sql = "INSERT INTO resumes (user_id, resume_title, first_name, last_name, phone, address, " +
                "linkedin_url, github_url, portfolio_url, professional_summary, target_job_title, ats_score) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, resume.getUserId());
            ps.setString(2, resume.getResumeTitle());
            ps.setString(3, resume.getFirstName());
            ps.setString(4, resume.getLastName());
            ps.setString(5, resume.getPhone());
            ps.setString(6, resume.getAddress());
            ps.setString(7, resume.getLinkedinUrl());
            ps.setString(8, resume.getGithubUrl());
            ps.setString(9, resume.getPortfolioUrl());
            ps.setString(10, resume.getProfessionalSummary());
            ps.setString(11, resume.getTargetJobTitle());
            ps.setDouble(12, resume.getAtsScore());
            if (ps.executeUpdate() > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) generatedId = rs.getInt(1);
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return generatedId;
    }

    public List<Resume> getResumesByUserId(int userId) {
        List<Resume> list = new ArrayList<>();
        String sql = "SELECT * FROM resumes WHERE user_id = ? ORDER BY id DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public Resume getResumeById(int resumeId) {
        String sql = "SELECT * FROM resumes WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, resumeId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    public boolean updateAtsScore(int resumeId, double score) {
        String sql = "UPDATE resumes SET ats_score = ? WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDouble(1, score);
            ps.setInt(2, resumeId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }

    public boolean deleteResume(int resumeId) {
        String sql = "DELETE FROM resumes WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, resumeId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }

    private Resume mapRow(ResultSet rs) throws SQLException {
        Resume r = new Resume();
        r.setId(rs.getInt("id"));
        r.setUserId(rs.getInt("user_id"));
        r.setResumeTitle(rs.getString("resume_title"));
        r.setFirstName(rs.getString("first_name"));
        r.setLastName(rs.getString("last_name"));
        r.setPhone(rs.getString("phone"));
        r.setAddress(rs.getString("address"));
        r.setLinkedinUrl(rs.getString("linkedin_url"));
        r.setGithubUrl(rs.getString("github_url"));
        r.setPortfolioUrl(rs.getString("portfolio_url"));
        r.setProfessionalSummary(rs.getString("professional_summary"));
        r.setTargetJobTitle(rs.getString("target_job_title"));
        r.setAtsScore(rs.getDouble("ats_score"));
        return r;
    }
}
