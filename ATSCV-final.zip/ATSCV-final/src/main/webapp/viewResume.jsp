<%@ page import="com.example.atscv.model.*,java.util.List" %>
<%@ page session="true" contentType="text/html;charset=UTF-8" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null) { response.sendRedirect("login.jsp"); return; }
    Resume resume = (Resume) request.getAttribute("resume");
    if (resume == null) { response.sendRedirect("myResumes"); return; }
    List<Education> eduList = (List<Education>) request.getAttribute("educationList");
    List<Experience> expList = (List<Experience>) request.getAttribute("experienceList");
    List<Skill> skillList = (List<Skill>) request.getAttribute("skillList");
    List<Project> projList = (List<Project>) request.getAttribute("projectList");
    List<Certification> certList = (List<Certification>) request.getAttribute("certificationList");
    double score = resume.getAtsScore();
    String scoreClass = score==0?"score-none":score>=75?"score-high":score>=50?"score-mid":"score-low";
    String scoreText = score>0?"ATS "+(int)score+"%":"Not Analyzed";
%>
<!DOCTYPE html><html><head><title><%=resume.getResumeTitle()!=null?resume.getResumeTitle():"Resume"%> - ATSCV</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:"Segoe UI",Arial,sans-serif;}
body{background:linear-gradient(135deg,#020817,#06122f,#0f172a);color:#fff;min-height:100vh;}
a{text-decoration:none;color:inherit;}
.action-bar{background:rgba(15,23,42,0.95);border-bottom:1px solid rgba(148,163,184,0.1);padding:14px 32px;display:flex;align-items:center;justify-content:space-between;gap:16px;}
.back-link{display:inline-flex;align-items:center;gap:8px;color:#94a3b8;font-size:14px;font-weight:600;padding:8px 14px;border-radius:10px;background:rgba(30,41,59,0.7);border:1px solid rgba(148,163,184,0.1);}
.back-link:hover{color:#fff;}
.rtitle{font-size:17px;font-weight:700;}.rsub{color:#94a3b8;font-size:13px;}
.score-badge{padding:8px 16px;border-radius:999px;font-size:14px;font-weight:700;}
.score-high{background:rgba(34,197,94,0.12);color:#86efac;border:1px solid rgba(34,197,94,0.25);}
.score-mid{background:rgba(234,179,8,0.12);color:#fde047;border:1px solid rgba(234,179,8,0.25);}
.score-low{background:rgba(239,68,68,0.1);color:#fca5a5;border:1px solid rgba(239,68,68,0.2);}
.score-none{background:rgba(148,163,184,0.1);color:#94a3b8;border:1px solid rgba(148,163,184,0.15);}
.btns{display:flex;gap:10px;}
.btn{padding:10px 20px;border-radius:12px;font-size:14px;font-weight:700;cursor:pointer;border:none;transition:all 0.2s;}
.btn-print{background:rgba(30,41,59,0.9);color:#e2e8f0;border:1px solid rgba(148,163,184,0.15);}
.btn-analyze{background:linear-gradient(135deg,#2563eb,#3b82f6);color:white;box-shadow:0 8px 16px rgba(37,99,235,0.25);}
.page-wrap{padding:32px;display:flex;gap:24px;align-items:flex-start;}
.resume-doc{flex:1;background:#fff;color:#1a202c;border-radius:12px;box-shadow:0 24px 60px rgba(0,0,0,0.4);overflow:hidden;max-width:860px;}
.doc-header{background:linear-gradient(135deg,#1e3a5f,#2563eb);color:white;padding:36px 40px;}
.doc-header h1{font-size:30px;font-weight:800;margin-bottom:4px;}
.doc-header .role{font-size:15px;opacity:0.85;margin-bottom:16px;}
.doc-contacts{display:flex;flex-wrap:wrap;gap:10px 22px;font-size:13px;opacity:0.9;}
.doc-body{padding:32px 40px;}
.doc-section{margin-bottom:26px;}
.doc-section-title{font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:2px;color:#2563eb;margin-bottom:12px;padding-bottom:6px;border-bottom:2px solid #dbeafe;}
.doc-section p{font-size:14px;line-height:1.7;color:#374151;}
.entry{margin-bottom:16px;}
.entry-header{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:4px;}
.entry-title{font-size:15px;font-weight:700;color:#111827;}
.entry-sub{font-size:13px;color:#6b7280;margin-bottom:4px;}
.entry-date{font-size:12px;color:#9ca3af;white-space:nowrap;}
.entry-body{font-size:13px;color:#374151;line-height:1.7;}
.skills-wrap{display:flex;flex-wrap:wrap;gap:8px;}
.skill-chip{padding:5px 14px;border-radius:999px;font-size:12px;font-weight:600;background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe;}
.proj-title{font-size:15px;font-weight:700;color:#111827;margin-bottom:4px;}
.proj-tech{font-size:12px;color:#6b7280;margin-bottom:4px;}
.proj-link{font-size:12px;color:#2563eb;}
.cert-row{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:12px;}
.cert-name{font-size:14px;font-weight:700;color:#111827;}
.cert-org{font-size:13px;color:#6b7280;}
.cert-date{font-size:12px;color:#9ca3af;white-space:nowrap;}
.side-panel{width:260px;flex-shrink:0;display:flex;flex-direction:column;gap:16px;}
.side-card{background:rgba(15,23,42,0.84);border:1px solid rgba(148,163,184,0.12);border-radius:18px;padding:20px;}
.side-card h4{font-size:14px;font-weight:700;margin-bottom:12px;color:#e2e8f0;}
.side-row{display:flex;justify-content:space-between;font-size:13px;padding:8px 0;border-bottom:1px solid rgba(148,163,184,0.07);color:#cbd5e1;}
.side-row:last-child{border-bottom:none;}
.side-row span:last-child{color:#93c5fd;font-weight:700;}
.qa{display:block;padding:11px 14px;border-radius:12px;font-size:13px;font-weight:700;text-align:center;margin-bottom:10px;transition:background 0.2s;}
.qa-blue{background:rgba(37,99,235,0.15);border:1px solid rgba(59,130,246,0.25);color:#93c5fd;}
.qa-blue:hover{background:rgba(37,99,235,0.25);}
.qa-gray{background:rgba(30,41,59,0.9);border:1px solid rgba(148,163,184,0.15);color:#e2e8f0;}
.score-bar-wrap{height:8px;background:rgba(255,255,255,0.07);border-radius:999px;overflow:hidden;}
.score-bar-fill{height:100%;background:linear-gradient(90deg,#2563eb,#60a5fa);border-radius:999px;}
@media print{.action-bar,.side-panel{display:none!important}body{background:white!important}.page-wrap{padding:0!important}.resume-doc{box-shadow:none;border-radius:0;max-width:100%;}}
@media(max-width:1100px){.side-panel{display:none}}
@media(max-width:700px){.page-wrap{padding:16px}.doc-body,.doc-header{padding:24px 20px}}
</style></head>
<body>
<div class="action-bar">
    <div style="display:flex;align-items:center;gap:16px">
        <a href="myResumes" class="back-link">← My Resumes</a>
        <div><div class="rtitle"><%=resume.getResumeTitle()!=null?resume.getResumeTitle():"Resume"%></div>
        <div class="rsub"><%=resume.getTargetJobTitle()!=null?resume.getTargetJobTitle():"No target role"%></div></div>
    </div>
    <div style="display:flex;align-items:center;gap:12px">
        <span class="score-badge <%=scoreClass%>"><%=scoreText%></span>
        <div class="btns">
            <button class="btn btn-print" onclick="window.print()">🖨 Print</button>
            <a href="atsAnalysis?resumeId=<%=resume.getId()%>" class="btn btn-analyze">Run ATS Check</a>
        </div>
    </div>
</div>
<div class="page-wrap">
<div class="resume-doc">
    <div class="doc-header">
        <h1><%=resume.getFirstName()!=null?resume.getFirstName():""%> <%=resume.getLastName()!=null?resume.getLastName():""%></h1>
        <div class="role"><%=resume.getTargetJobTitle()!=null?resume.getTargetJobTitle():""%></div>
        <div class="doc-contacts">
            <%if(resume.getPhone()!=null&&!resume.getPhone().isEmpty()){%><span>📞 <%=resume.getPhone()%></span><%}%>
            <%if(resume.getAddress()!=null&&!resume.getAddress().isEmpty()){%><span>📍 <%=resume.getAddress()%></span><%}%>
            <%if(resume.getLinkedinUrl()!=null&&!resume.getLinkedinUrl().isEmpty()){%><span>💼 LinkedIn</span><%}%>
            <%if(resume.getGithubUrl()!=null&&!resume.getGithubUrl().isEmpty()){%><span>🐙 GitHub</span><%}%>
            <%if(resume.getPortfolioUrl()!=null&&!resume.getPortfolioUrl().isEmpty()){%><span>🌐 Portfolio</span><%}%>
        </div>
    </div>
    <div class="doc-body">
        <%if(resume.getProfessionalSummary()!=null&&!resume.getProfessionalSummary().isEmpty()){%>
        <div class="doc-section"><div class="doc-section-title">Professional Summary</div><p><%=resume.getProfessionalSummary()%></p></div>
        <%}%>
        <%if(expList!=null&&!expList.isEmpty()){%>
        <div class="doc-section"><div class="doc-section-title">Professional Experience</div>
        <%for(Experience ex:expList){%>
        <div class="entry">
            <div class="entry-header">
                <div><div class="entry-title"><%=ex.getJobTitle()!=null?ex.getJobTitle():""%></div>
                <div class="entry-sub"><%=ex.getCompanyName()!=null?ex.getCompanyName():""%><%if(ex.getLocation()!=null&&!ex.getLocation().isEmpty()){%> · <%=ex.getLocation()%><%}%></div></div>
                <div class="entry-date"><%=ex.getStartDate()!=null?ex.getStartDate().toString().substring(0,7):""%> — <%=ex.isCurrentlyWorking()?"Present":ex.getEndDate()!=null?ex.getEndDate().toString().substring(0,7):""%></div>
            </div>
            <%if(ex.getResponsibilities()!=null&&!ex.getResponsibilities().isEmpty()){%><div class="entry-body"><p><%=ex.getResponsibilities()%></p></div><%}%>
            <%if(ex.getAchievements()!=null&&!ex.getAchievements().isEmpty()){%><div class="entry-body" style="margin-top:6px"><strong style="font-size:12px">Achievements:</strong> <%=ex.getAchievements()%></div><%}%>
        </div><%}%></div><%}%>
        <%if(eduList!=null&&!eduList.isEmpty()){%>
        <div class="doc-section"><div class="doc-section-title">Education</div>
        <%for(Education ed:eduList){%>
        <div class="entry">
            <div class="entry-header">
                <div><div class="entry-title"><%=ed.getInstitutionName()!=null?ed.getInstitutionName():""%></div>
                <div class="entry-sub"><%=ed.getQualification()!=null?ed.getQualification():""%><%if(ed.getFieldOfStudy()!=null&&!ed.getFieldOfStudy().isEmpty()){%> in <%=ed.getFieldOfStudy()%><%}%><%if(ed.getGrade()!=null&&!ed.getGrade().isEmpty()){%> · <%=ed.getGrade()%><%}%></div></div>
                <div class="entry-date"><%=ed.getStartDate()!=null?ed.getStartDate().toString().substring(0,7):""%><%if(ed.getEndDate()!=null){%> — <%=ed.getEndDate().toString().substring(0,7)%><%}%></div>
            </div>
            <%if(ed.getDescription()!=null&&!ed.getDescription().isEmpty()){%><div class="entry-body"><p><%=ed.getDescription()%></p></div><%}%>
        </div><%}%></div><%}%>
        <%if(skillList!=null&&!skillList.isEmpty()){%>
        <div class="doc-section"><div class="doc-section-title">Skills</div>
        <div class="skills-wrap"><%for(Skill s:skillList){%><span class="skill-chip"><%=s.getSkillName()%></span><%}%></div>
        </div><%}%>
        <%if(projList!=null&&!projList.isEmpty()){%>
        <div class="doc-section"><div class="doc-section-title">Projects</div>
        <%for(Project p:projList){%>
        <div style="margin-bottom:14px">
            <div class="proj-title"><%=p.getProjectTitle()!=null?p.getProjectTitle():""%></div>
            <%if(p.getTechnologiesUsed()!=null&&!p.getTechnologiesUsed().isEmpty()){%><div class="proj-tech">Tech: <%=p.getTechnologiesUsed()%></div><%}%>
            <%if(p.getProjectLink()!=null&&!p.getProjectLink().isEmpty()){%><div><a href="<%=p.getProjectLink()%>" class="proj-link" target="_blank"><%=p.getProjectLink()%></a></div><%}%>
            <%if(p.getDescription()!=null&&!p.getDescription().isEmpty()){%><p style="font-size:13px;color:#374151;line-height:1.6;margin-top:4px"><%=p.getDescription()%></p><%}%>
        </div><%}%></div><%}%>
        <%if(certList!=null&&!certList.isEmpty()){%>
        <div class="doc-section"><div class="doc-section-title">Certifications</div>
        <%for(Certification c:certList){%>
        <div class="cert-row">
            <div><div class="cert-name"><%=c.getCertificateName()!=null?c.getCertificateName():""%></div>
            <div class="cert-org"><%=c.getIssuingOrganization()!=null?c.getIssuingOrganization():""%></div>
            <%if(c.getCredentialUrl()!=null&&!c.getCredentialUrl().isEmpty()){%><a href="<%=c.getCredentialUrl()%>" class="proj-link" target="_blank" style="font-size:12px">View Credential</a><%}%></div>
            <div class="cert-date"><%if(c.getIssueDate()!=null){%><%=c.getIssueDate().toString().substring(0,7)%><%}%><%if(c.getExpiryDate()!=null){%><br>Exp: <%=c.getExpiryDate().toString().substring(0,7)%><%}%></div>
        </div><%}%></div><%}%>
    </div>
</div>
<div class="side-panel">
    <div class="side-card">
        <h4>Resume Summary</h4>
        <div class="side-row"><span>Resume ID</span><span>#<%=resume.getId()%></span></div>
        <div class="side-row"><span>ATS Score</span><span><%=score>0?(int)score+"%":"—"%></span></div>
        <div class="side-row"><span>Experience</span><span><%=expList!=null?expList.size():0%> entries</span></div>
        <div class="side-row"><span>Education</span><span><%=eduList!=null?eduList.size():0%> entries</span></div>
        <div class="side-row"><span>Skills</span><span><%=skillList!=null?skillList.size():0%></span></div>
        <div class="side-row"><span>Projects</span><span><%=projList!=null?projList.size():0%></span></div>
        <div class="side-row"><span>Certifications</span><span><%=certList!=null?certList.size():0%></span></div>
    </div>
    <div class="side-card">
        <h4>Quick Actions</h4>
        <a href="atsAnalysis?resumeId=<%=resume.getId()%>" class="qa qa-blue">🔍 Run ATS Analysis</a>
        <button onclick="window.print()" class="qa qa-gray" style="cursor:pointer;font-family:inherit;width:100%">🖨 Print Resume</button>
        <a href="myResumes" class="qa qa-gray">← Back to My Resumes</a>
    </div>
    <%if(score>0){%>
    <div class="side-card">
        <h4>Score</h4>
        <p style="font-size:14px;margin-bottom:12px;color:#cbd5e1">ATS Score: <strong style="color:<%=score>=75?"#86efac":score>=50?"#fde047":"#fca5a5"%>"><%=(int)score%>%</strong></p>
        <div class="score-bar-wrap"><div class="score-bar-fill" style="width:<%=(int)score%>%"></div></div>
        <p style="margin-top:8px;font-size:12px;color:#64748b">Run a new analysis to update this score.</p>
    </div>
    <%}%>
</div>
</div>
</body></html>
