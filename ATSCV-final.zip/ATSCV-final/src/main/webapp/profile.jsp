<%@ page import="com.example.atscv.model.User" %>
<%@ page session="true" contentType="text/html;charset=UTF-8" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null) { response.sendRedirect("login.jsp"); return; }
    String successMessage = (String) request.getAttribute("successMessage");
    String errorMessage = (String) request.getAttribute("errorMessage");
%>
<!DOCTYPE html><html><head><title>Profile - ATSCV</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:"Segoe UI",Arial,sans-serif;}
body{background:linear-gradient(135deg,#020817,#06122f,#0f172a);color:#fff;min-height:100vh;}
a{text-decoration:none;color:inherit;}
.layout{display:grid;grid-template-columns:260px 1fr;min-height:100vh;}
.sidebar{background:rgba(15,23,42,0.95);border-right:1px solid rgba(148,163,184,0.12);padding:28px 20px;}
.brand{display:inline-block;padding:8px 14px;border-radius:999px;background:rgba(59,130,246,0.15);border:1px solid rgba(96,165,250,0.28);color:#93c5fd;font-size:12px;font-weight:700;letter-spacing:1px;margin-bottom:26px;}
.user-box{background:rgba(30,41,59,0.78);border:1px solid rgba(148,163,184,0.12);border-radius:18px;padding:16px;margin-bottom:24px;}
.user-box h3{font-size:16px;margin-bottom:4px;}.user-box p{color:#94a3b8;font-size:13px;}
.menu{display:grid;gap:8px;}
.menu a{display:block;color:#e2e8f0;background:rgba(30,41,59,0.65);border:1px solid rgba(148,163,184,0.10);padding:13px 16px;border-radius:14px;font-size:14px;font-weight:600;transition:all 0.2s;}
.menu a:hover,.menu a.active{background:linear-gradient(135deg,rgba(37,99,235,0.28),rgba(59,130,246,0.22));border-color:rgba(96,165,250,0.35);}
.main{padding:32px;max-width:820px;}
.topbar{margin-bottom:28px;}.topbar h1{font-size:28px;font-weight:800;}.topbar p{color:#94a3b8;font-size:14px;margin-top:4px;}
.alert{padding:14px 18px;border-radius:14px;font-size:14px;margin-bottom:20px;line-height:1.6;}
.alert-success{background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.25);color:#86efac;}
.alert-error{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:#fca5a5;}
.avatar-section{background:rgba(15,23,42,0.84);border:1px solid rgba(148,163,184,0.12);border-radius:22px;padding:28px;margin-bottom:20px;display:flex;align-items:center;gap:24px;}
.avatar-circle{width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#2563eb,#8b5cf6);display:flex;align-items:center;justify-content:center;font-size:30px;font-weight:800;flex-shrink:0;}
.avatar-info h2{font-size:22px;margin-bottom:4px;}.avatar-info p{color:#94a3b8;font-size:14px;}
.avatar-info .badge{display:inline-block;padding:4px 12px;border-radius:999px;background:rgba(34,197,94,0.12);border:1px solid rgba(34,197,94,0.25);color:#86efac;font-size:12px;font-weight:700;margin-top:8px;}
.panel{background:rgba(15,23,42,0.84);border:1px solid rgba(148,163,184,0.12);border-radius:22px;padding:26px;margin-bottom:20px;}
.panel h3{font-size:18px;margin-bottom:6px;}.panel .sub{color:#94a3b8;font-size:13px;margin-bottom:22px;line-height:1.6;}
.divider{height:1px;background:rgba(148,163,184,0.08);margin:20px 0;}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.field{display:flex;flex-direction:column;gap:8px;margin-bottom:4px;}
.field label{font-size:12px;font-weight:700;color:#a5b4fc;letter-spacing:0.8px;text-transform:uppercase;}
.field input{width:100%;padding:13px 14px;background:#16233f;border:1px solid rgba(255,255,255,0.07);color:#fff;border-radius:14px;font-size:14px;outline:none;transition:all 0.2s;}
.field input:focus{border-color:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,0.12);}
.save-btn{padding:13px 28px;border:none;border-radius:14px;background:linear-gradient(135deg,#2563eb,#3b82f6);color:white;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 10px 20px rgba(37,99,235,0.25);font-family:inherit;}
.save-btn:hover{opacity:0.9;}
.danger-zone{background:rgba(239,68,68,0.05);border:1px solid rgba(239,68,68,0.18);border-radius:22px;padding:26px;margin-bottom:20px;}
.danger-zone h3{font-size:18px;color:#fca5a5;margin-bottom:6px;}.danger-zone .sub{color:#94a3b8;font-size:13px;margin-bottom:20px;}
.danger-btn{padding:12px 22px;border:1px solid rgba(239,68,68,0.2);border-radius:12px;background:rgba(239,68,68,0.12);color:#fca5a5;font-size:14px;font-weight:700;cursor:pointer;font-family:inherit;}
.mismatch{color:#fca5a5;font-size:13px;margin-top:8px;display:none;}
@media(max-width:900px){.layout{grid-template-columns:1fr}.sidebar{display:none}}
@media(max-width:600px){.grid2{grid-template-columns:1fr}.avatar-section{flex-direction:column}}
</style></head>
<body>
<div class="layout">
<aside class="sidebar">
    <div class="brand">ATS CV BUILDER</div>
    <div class="user-box"><h3><%=user.getFullName()%></h3><p><%=user.getEmail()%></p></div>
    <nav class="menu">
        <a href="dashboard.jsp">Dashboard</a><a href="buildCV">Build CV</a>
        <a href="myResumes">My Resumes</a><a href="atsAnalysis">ATS Analysis</a>
        <a href="results">Results</a><a href="profile" class="active">Profile</a><a href="logout">Logout</a>
    </nav>
</aside>
<main class="main">
    <div class="topbar"><h1>My Profile</h1><p>Manage your account details and password.</p></div>
    <%if(successMessage!=null){%><div class="alert alert-success"><%=successMessage%></div><%}%>
    <%if(errorMessage!=null){%><div class="alert alert-error"><%=errorMessage%></div><%}%>
    <div class="avatar-section">
        <div class="avatar-circle"><%=user.getFullName()!=null&&user.getFullName().length()>0?user.getFullName().substring(0,1).toUpperCase():"?"%></div>
        <div class="avatar-info">
            <h2><%=user.getFullName()%></h2>
            <p><%=user.getEmail()%></p>
            <span class="badge">Active Account</span>
        </div>
    </div>
    <div class="panel">
        <h3>Account Details</h3><p class="sub">Update your name and email address.</p>
        <form action="profile" method="post">
            <input type="hidden" name="action" value="updateProfile">
            <div class="grid2">
                <div class="field"><label>Full Name</label><input type="text" name="fullName" value="<%=user.getFullName()!=null?user.getFullName():""%>" required></div>
                <div class="field"><label>Email Address</label><input type="email" name="email" value="<%=user.getEmail()!=null?user.getEmail():""%>" required></div>
            </div>
            <div class="divider"></div>
            <button type="submit" class="save-btn">Save Changes</button>
        </form>
    </div>
    <div class="panel">
        <h3>Change Password</h3><p class="sub">Choose a strong password with at least 8 characters.</p>
        <form action="profile" method="post">
            <input type="hidden" name="action" value="changePassword">
            <div class="field" style="margin-bottom:16px"><label>Current Password</label><input type="password" name="currentPassword" placeholder="Enter your current password" required></div>
            <div class="grid2">
                <div class="field"><label>New Password</label><input type="password" name="newPassword" id="newPwd" placeholder="Minimum 8 characters" minlength="8" required></div>
                <div class="field"><label>Confirm New Password</label><input type="password" name="confirmPassword" id="confirmPwd" placeholder="Repeat new password" required></div>
            </div>
            <div class="mismatch" id="pwdMismatch">Passwords do not match.</div>
            <div class="divider"></div>
            <button type="submit" class="save-btn" onclick="return checkPwd()">Update Password</button>
        </form>
    </div>
    <div class="danger-zone">
        <h3>Danger Zone</h3><p class="sub">Deleting your account is permanent and cannot be undone. All resumes and data will be lost.</p>
        <button class="danger-btn" onclick="confirmDelete()">Delete My Account</button>
    </div>
</main>
</div>
<script>
function checkPwd(){
    var np=document.getElementById('newPwd').value, cp=document.getElementById('confirmPwd').value;
    if(np!==cp){document.getElementById('pwdMismatch').style.display='block';return false;}
    document.getElementById('pwdMismatch').style.display='none';return true;
}
function confirmDelete(){
    if(confirm('Are you absolutely sure? This will permanently delete your account and all your data.'))
        window.location.href='deleteAccount';
}
</script>
</body></html>
