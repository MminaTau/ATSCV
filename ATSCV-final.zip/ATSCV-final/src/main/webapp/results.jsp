<%@ page import="com.example.atscv.model.User,com.example.atscv.model.Resume,com.example.atscv.dao.ResumeDAO,java.util.List" %>
<%@ page session="true" contentType="text/html;charset=UTF-8" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null) { response.sendRedirect("login.jsp"); return; }
    List<Resume> resumes = new ResumeDAO().getResumesByUserId(user.getId());
    int total = resumes!=null?resumes.size():0;
    double best=0,totalScore=0; int analyzed=0;
    if(resumes!=null)for(Resume r:resumes){if(r.getAtsScore()>0){analyzed++;totalScore+=r.getAtsScore();if(r.getAtsScore()>best)best=r.getAtsScore();}}
    double avg = analyzed>0?totalScore/analyzed:0;
%>
<!DOCTYPE html><html><head><title>Results - ATSCV</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:"Segoe UI",Arial,sans-serif;}
body{background:linear-gradient(135deg,#020817,#06122f,#0f172a);color:#fff;min-height:100vh;}
a{text-decoration:none;color:inherit;}
.layout{display:grid;grid-template-columns:260px 1fr;min-height:100vh;}
.sidebar{background:rgba(15,23,42,0.95);border-right:1px solid rgba(148,163,184,0.12);padding:28px 20px;}
.brand{display:inline-block;padding:8px 14px;border-radius:999px;background:rgba(59,130,246,0.15);border:1px solid rgba(96,165,250,0.28);color:#93c5fd;font-size:12px;font-weight:700;letter-spacing:1px;margin-bottom:26px;}
.user-box{background:rgba(30,41,59,0.78);border:1px solid rgba(148,163,184,0.12);border-radius:18px;padding:16px;margin-bottom:24px;}
.user-box h3{font-size:16px;margin-bottom:4px;}.user-box p{color:#94a3b8;font-size:13px;}
.menu{display:grid;gap:8px;}
.menu a{display:block;color:#e2e8f0;background:rgba(30,41,59,0.65);border:1px solid rgba(148,163,184,0.10);padding:13px 16px;border-radius:14px;font-size:14px;font-weight:600;transition:all 0.2s;}
.menu a:hover,.menu a.active{background:linear-gradient(135deg,rgba(37,99,235,0.28),rgba(59,130,246,0.22));border-color:rgba(96,165,250,0.35);}
.main{padding:32px;}
.topbar{margin-bottom:28px;}.topbar h1{font-size:28px;font-weight:800;}.topbar p{color:#94a3b8;font-size:14px;margin-top:4px;}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:28px;}
.stat{background:rgba(15,23,42,0.84);border:1px solid rgba(148,163,184,0.12);border-radius:20px;padding:20px;}
.stat .lbl{color:#94a3b8;font-size:12px;text-transform:uppercase;letter-spacing:0.8px;margin-bottom:10px;}
.stat .val{font-size:28px;font-weight:800;margin-bottom:6px;}
.stat .hint{color:#64748b;font-size:12px;}
.panel{background:rgba(15,23,42,0.84);border:1px solid rgba(148,163,184,0.12);border-radius:22px;padding:24px;margin-bottom:22px;}
.panel h3{font-size:18px;margin-bottom:6px;}.panel .sub{color:#94a3b8;font-size:13px;margin-bottom:20px;}
table{width:100%;border-collapse:collapse;}
th{text-align:left;font-size:12px;color:#64748b;text-transform:uppercase;letter-spacing:0.8px;padding:10px 14px;border-bottom:1px solid rgba(148,163,184,0.1);}
td{padding:14px;font-size:14px;color:#e2e8f0;border-bottom:1px solid rgba(148,163,184,0.07);}
tr:last-child td{border-bottom:none;}
tr:hover td{background:rgba(30,41,59,0.5);}
.pill{display:inline-block;padding:4px 12px;border-radius:999px;font-size:13px;font-weight:700;}
.pill-high{background:rgba(34,197,94,0.12);color:#86efac;border:1px solid rgba(34,197,94,0.25);}
.pill-mid{background:rgba(234,179,8,0.12);color:#fde047;border:1px solid rgba(234,179,8,0.25);}
.pill-low{background:rgba(239,68,68,0.1);color:#fca5a5;border:1px solid rgba(239,68,68,0.2);}
.pill-none{background:rgba(148,163,184,0.1);color:#94a3b8;border:1px solid rgba(148,163,184,0.15);}
.bar-wrap{height:8px;background:rgba(255,255,255,0.07);border-radius:999px;overflow:hidden;}
.bar-fill{height:100%;border-radius:999px;background:linear-gradient(90deg,#2563eb,#60a5fa);}
.act-link{color:#60a5fa;font-size:13px;font-weight:700;padding:6px 12px;border-radius:10px;background:rgba(59,130,246,0.1);}
.empty{text-align:center;padding:60px 30px;}
.empty .icon{font-size:48px;margin-bottom:16px;}.empty h3{font-size:20px;margin-bottom:10px;}
.empty p{color:#94a3b8;font-size:14px;line-height:1.7;margin-bottom:22px;}
.cta{display:inline-block;padding:13px 26px;background:linear-gradient(135deg,#2563eb,#3b82f6);color:white;border-radius:14px;font-weight:700;font-size:14px;}
.tips-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.tip{background:rgba(30,41,59,0.7);border-radius:14px;padding:16px;}
.tip .ti{font-size:20px;margin-bottom:8px;}.tip .tt{font-size:14px;font-weight:700;margin-bottom:6px;}
.tip .td{color:#94a3b8;font-size:13px;line-height:1.6;}
@media(max-width:1100px){.stats{grid-template-columns:repeat(2,1fr)}}
@media(max-width:900px){.layout{grid-template-columns:1fr}.sidebar{display:none}}
@media(max-width:600px){.stats{grid-template-columns:1fr}.tips-grid{grid-template-columns:1fr}}
</style></head>
<body>
<div class="layout">
<aside class="sidebar">
    <div class="brand">ATS CV BUILDER</div>
    <div class="user-box"><h3><%=user.getFullName()%></h3><p><%=user.getEmail()%></p></div>
    <nav class="menu">
        <a href="dashboard.jsp">Dashboard</a><a href="buildCV">Build CV</a>
        <a href="myResumes">My Resumes</a><a href="atsAnalysis">ATS Analysis</a>
        <a href="results" class="active">Results</a><a href="profile">Profile</a><a href="logout">Logout</a>
    </nav>
</aside>
<main class="main">
    <div class="topbar"><h1>Results</h1><p>Overview of all your ATS scores and resume performance.</p></div>
    <div class="stats">
        <div class="stat"><div class="lbl">Total Resumes</div><div class="val" style="color:#93c5fd"><%=total%></div><div class="hint">Saved in your account</div></div>
        <div class="stat"><div class="lbl">Analyzed</div><div class="val"><%=analyzed%></div><div class="hint">CVs with ATS scores</div></div>
        <div class="stat"><div class="lbl">Best Score</div><div class="val" style="color:#86efac"><%=best>0?(int)best+"%":"--"%></div><div class="hint">Your top performing CV</div></div>
        <div class="stat"><div class="lbl">Average Score</div><div class="val" style="color:#fde047"><%=avg>0?String.format("%.0f",avg)+"%":"--"%></div><div class="hint">Across all analyzed CVs</div></div>
    </div>
    <div class="panel">
        <h3>Resume Scores</h3><p class="sub">All your resumes and their ATS analysis results.</p>
        <% if(resumes==null||resumes.isEmpty()){%>
        <div class="empty">
            <div class="icon">📊</div><h3>No Results Yet</h3>
            <p>Build a CV and run an ATS analysis to see your scores here.</p>
            <a href="buildCV" class="cta">Build Your First CV</a>
        </div>
        <%}else{%>
        <table>
            <thead><tr><th>Resume</th><th>Target Role</th><th>ATS Score</th><th>Score Bar</th><th>Action</th></tr></thead>
            <tbody>
            <%for(Resume r:resumes){boolean hs=r.getAtsScore()>0;
              String pc=!hs?"pill-none":r.getAtsScore()>=75?"pill-high":r.getAtsScore()>=50?"pill-mid":"pill-low";
              String sd=hs?(int)r.getAtsScore()+"%":"Not Analyzed";%>
            <tr>
                <td><strong><%=r.getResumeTitle()!=null?r.getResumeTitle():"Untitled"%></strong><br><span style="color:#64748b;font-size:12px;">ID #<%=r.getId()%></span></td>
                <td style="color:#94a3b8"><%=r.getTargetJobTitle()!=null?r.getTargetJobTitle():"—"%></td>
                <td><span class="pill <%=pc%>"><%=sd%></span></td>
                <td style="min-width:120px"><div class="bar-wrap"><div class="bar-fill" style="width:<%=(int)r.getAtsScore()%>%"></div></div></td>
                <td><a href="atsAnalysis?resumeId=<%=r.getId()%>" class="act-link">Analyze →</a></td>
            </tr>
            <%}%>
            </tbody>
        </table>
        <%}%>
    </div>
    <div class="panel">
        <h3>Tips to Improve Your Scores</h3><p class="sub">Follow these best practices to consistently score above 75%.</p>
        <div class="tips-grid">
            <div class="tip"><div class="ti">🎯</div><div class="tt">Mirror Job Keywords</div><div class="td">Use exact terms from the job description in your skills and experience.</div></div>
            <div class="tip"><div class="ti">📋</div><div class="tt">Complete All Sections</div><div class="td">Resumes with all sections filled score significantly higher.</div></div>
            <div class="tip"><div class="ti">📊</div><div class="tt">Quantify Achievements</div><div class="td">Use numbers, percentages and measurable outcomes throughout.</div></div>
            <div class="tip"><div class="ti">✍️</div><div class="tt">Tailor Per Application</div><div class="td">Create a different CV version for each role you apply for.</div></div>
        </div>
    </div>
</main>
</div>
</body></html>
