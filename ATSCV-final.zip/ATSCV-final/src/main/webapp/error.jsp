<%@ page contentType="text/html;charset=UTF-8" isErrorPage="true" %>
<!DOCTYPE html><html><head><title>Error - ATSCV</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:"Segoe UI",sans-serif;}
body{background:linear-gradient(135deg,#020817,#06122f,#0f172a);color:#fff;min-height:100vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:30px;}
.code{font-size:120px;font-weight:800;background:linear-gradient(135deg,#dc2626,#f87171);-webkit-background-clip:text;-webkit-text-fill-color:transparent;line-height:1;margin-bottom:16px;}
h1{font-size:28px;margin-bottom:14px;}p{color:#94a3b8;font-size:16px;line-height:1.7;margin-bottom:28px;}
.err{background:rgba(220,38,38,0.08);border:1px solid rgba(220,38,38,0.2);border-radius:14px;padding:16px;margin-bottom:28px;font-size:13px;color:#fca5a5;word-break:break-word;}
.btn{display:inline-block;padding:14px 30px;background:linear-gradient(135deg,#2563eb,#3b82f6);color:white;border-radius:14px;text-decoration:none;font-weight:700;margin:6px;}
</style></head>
<body><div style="max-width:600px">
<div class="code">500</div><h1>Something Went Wrong</h1>
<p>An unexpected server error occurred. Please try again.</p>
<% if (exception != null && exception.getMessage() != null) { %>
<div class="err"><%= exception.getMessage() %></div>
<% } %>
<a href="dashboard.jsp" class="btn">Go to Dashboard</a>
</div></body></html>
