<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html><html><head><title>404 - ATSCV</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:"Segoe UI",sans-serif;}
body{background:linear-gradient(135deg,#020817,#06122f,#0f172a);color:#fff;min-height:100vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:30px;}
.code{font-size:120px;font-weight:800;background:linear-gradient(135deg,#2563eb,#60a5fa);-webkit-background-clip:text;-webkit-text-fill-color:transparent;line-height:1;margin-bottom:16px;}
h1{font-size:28px;margin-bottom:14px;}p{color:#94a3b8;font-size:16px;line-height:1.7;margin-bottom:34px;}
.btn{display:inline-block;padding:14px 30px;background:linear-gradient(135deg,#2563eb,#3b82f6);color:white;border-radius:14px;text-decoration:none;font-weight:700;margin:6px;transition:transform 0.2s;}
.btn:hover{transform:translateY(-2px);}
.btn-ghost{background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.12);}
</style></head>
<body><div><div class="code">404</div><h1>Page Not Found</h1>
<p>The page you are looking for does not exist or has been moved.</p>
<a href="dashboard.jsp" class="btn">Go to Dashboard</a>
<a href="index.jsp" class="btn btn-ghost">Home</a>
</div></body></html>
