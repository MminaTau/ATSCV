<%@ page import="com.example.atscv.model.User,com.example.atscv.model.Resume,com.example.atscv.dao.ResumeDAO,java.util.List" %>
<%@ page session="true" contentType="text/html;charset=UTF-8" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null) { response.sendRedirect("login.jsp"); return; }
    List<Resume> resumes = new ResumeDAO().getResumesByUserId(user.getId());
    int total = resumes != null ? resumes.size() : 0;
    double best = 0; int analyzed = 0;
    if (resumes != null) for (Resume r : resumes) { if (r.getAtsScore()>best) best=r.getAtsScore(); if (r.getAtsScore()>0) analyzed++; }
%>
<!DOCTYPE html><html><head><title>My Resumes - ATSCV</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:"Segoe UI",Arial,sans-serif;}
body{background:linear-gradient(135deg,#020817,#06122f,#0f172a);color:#fff;min-height:100vh;}
a{text-decoration:none;color:inherit;}
.layout{display:grid;grid-template-columns:260px 1fr;min-height:100vh;}
.sidebar{background:rgba(15,23,42,0.95);border-right:1px solid rgba(148,163,184,0.12);padding:28px 20px;}
.brand{display:inline-block;padding:8px 14px;border-radius:999px;background:rgba(59,130,246,0.15);border:1px solid rgba(96,165,250,0.28);color:#93c5fd;font-size:12px;font-weight:700;letter-spacing:1px;margin-bottom:26px;}
.user-box{background:rgba(30,41,59,0.78);border:1px solid rgba(148,163,184,0.12);border-radius:18px;padding:16px;margin-bottom:24px;}
.user-box h3{font-size:16px;margin-bottom:4px;}
.user-box p{color:#94a3b8;font-size:13px;word-break:break-word;}
.menu{display:grid;gap:8px;}
.menu a{display:block;color:#e2e8f0;background:rgba(30,41,59,0.65);border:1px solid rgba(148,163,184,0.10);padding:13px 16px;border-radius:14px;font-size:14px;font-weight:600;transition:all 0.2s;}
.menu a:hover,.menu a.active{background:linear-gradient(135deg,rgba(37,99,235,0.28),rgba(59,130,246,0.22));border-color:rgba(96,165,250,0.35);}
.main{padding:32px;}
.topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:28px;}
.topbar h1{font-size:28px;font-weight:800;}
.topbar p{color:#94a3b8;font-size:14px;margin-top:4px;}
.new-btn{display:inline-flex;align-items:center;gap:8px;padding:13px 22px;background:linear-gradient(135deg,#2563eb,#3b82f6);color:white;border-radius:14px;font-weight:700;font-size:14px;box-shadow:0 10px 20px rgba(37,99,235,0.25);}
.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:24px;}
.stat{background:rgba(15,23,42,0.82);border:1px solid rgba(148,163,184,0.12);border-radius:18px;padding:20px;}
.stat .lbl{color:#94a3b8;font-size:13px;margin-bottom:8px;}
.stat .val{font-size:28px;font-weight:800;}
.toolbar{display:flex;gap:12px;margin-bottom:22px;}
.search-box{flex:1;padding:12px 16px;background:rgba(15,23,42,0.82);border:1px solid rgba(148,163,184,0.12);border-radius:12px;color:#fff;font-size:14px;outline:none;}
.search-box:focus{border-color:#3b82f6;}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px;}
.card{background:rgba(15,23,42,0.84);border:1px solid rgba(148,163,184,0.12);border-radius:20px;padding:22px;transition:transform 0.2s,border-color 0.2s;}
.card:hover{transform:translateY(-3px);border-color:rgba(96,165,250,0.28);}
.card-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px;}
.card-title{font-size:17px;font-weight:700;margin-bottom:4px;}
.card-job{color:#94a3b8;font-size:13px;}
.card-meta{color:#64748b;font-size:12px;margin-bottom:14px;}
.score-badge{padding:6px 12px;border-radius:999px;font-size:13px;font-weight:700;}
.score-high{background:rgba(34,197,94,0.12);color:#86efac;border:1px solid rgba(34,197,94,0.25);}
.score-mid{background:rgba(234,179,8,0.12);color:#fde047;border:1px solid rgba(234,179,8,0.25);}
.score-low{background:rgba(239,68,68,0.1);color:#fca5a5;border:1px solid rgba(239,68,68,0.2);}
.score-none{background:rgba(148,163,184,0.1);color:#94a3b8;border:1px solid rgba(148,163,184,0.15);}
.tags{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px;}
.tag{padding:4px 10px;border-radius:999px;background:rgba(30,41,59,0.9);border:1px solid rgba(148,163,184,0.1);color:#cbd5e1;font-size:12px;}
.actions{display:flex;gap:8px;}
.abtn{flex:1;padding:10px;border-radius:12px;font-size:13px;font-weight:700;cursor:pointer;border:none;text-align:center;transition:all 0.2s;}
.abtn-view{background:rgba(37,99,235,0.15);color:#93c5fd;border:1px solid rgba(59,130,246,0.25);}
.abtn-view:hover{background:rgba(37,99,235,0.28);}
.abtn-analyze{background:rgba(34,197,94,0.1);color:#86efac;border:1px solid rgba(34,197,94,0.22);}
.abtn-analyze:hover{background:rgba(34,197,94,0.2);}
.abtn-delete{background:rgba(239,68,68,0.08);color:#fca5a5;border:1px solid rgba(239,68,68,0.2);}
.abtn-delete:hover{background:rgba(239,68,68,0.18);}
.empty{grid-column:1/-1;text-align:center;padding:70px 30px;background:rgba(15,23,42,0.6);border:1px dashed rgba(148,163,184,0.15);border-radius:22px;}
.empty .icon{font-size:52px;margin-bottom:18px;}
.empty h3{font-size:22px;margin-bottom:10px;}
.empty p{color:#94a3b8;font-size:15px;line-height:1.7;margin-bottom:24px;}
@media(max-width:900px){.layout{grid-template-columns:1fr}.sidebar{display:none}.stats{grid-template-columns:1fr}}
</style></head>
<body>
<div class="layout">
<aside class="sidebar">
    <div class="brand">ATS CV BUILDER</div>
    <div class="user-box"><h3><%=user.getFullName()%></h3><p><%=user.getEmail()%></p></div>
    <nav class="menu">
        <a href="dashboard.jsp">Dashboard</a>
        <a href="buildCV">Build CV</a>
        <a href="myResumes" class="active">My Resumes</a>
        <a href="atsAnalysis">ATS Analysis</a>
        <a href="results">Results</a>
        <a href="profile">Profile</a>
        <a href="logout">Logout</a>
    </nav>
</aside>
<main class="main">
    <div class="topbar">
        <div><h1>My Resumes</h1><p>View, manage and analyze all your saved CVs.</p></div>
        <a href="buildCV" class="new-btn">+ Create New CV</a>
    </div>
    <div class="stats">
        <div class="stat"><div class="lbl">Total Resumes</div><div class="val"><%=total%></div></div>
        <div class="stat"><div class="lbl">Best ATS Score</div><div class="val"><%=best>0?(int)best+"%":"--"%></div></div>
        <div class="stat"><div class="lbl">Analyzed</div><div class="val"><%=analyzed%></div></div>
    </div>
    <div class="toolbar">
        <input type="text" class="search-box" placeholder="Search resumes by title..." id="searchInput" oninput="filterCards()">
    </div>
    <div class="grid" id="resumeGrid">
    <% if (resumes == null || resumes.isEmpty()) { %>
        <div class="empty">
            <div class="icon">📄</div>
            <h3>No Resumes Yet</h3>
            <p>You have not created any CVs yet. Build your first ATS-optimized resume now.</p>
            <a href="buildCV" class="new-btn" style="display:inline-flex">+ Build Your First CV</a>
        </div>
    <% } else { for (Resume r : resumes) {
        String sc = r.getAtsScore()>=75?"score-high":r.getAtsScore()>=50?"score-mid":r.getAtsScore()>0?"score-low":"score-none";
        String st = r.getAtsScore()>0?(int)r.getAtsScore()+"%":"N/A";
    %>
        <div class="card" data-title="<%=r.getResumeTitle()!=null?r.getResumeTitle().toLowerCase():""%>">
            <div class="card-header">
                <div>
                    <div class="card-title"><%=r.getResumeTitle()!=null?r.getResumeTitle():"Untitled"%></div>
                    <div class="card-job"><%=r.getTargetJobTitle()!=null?r.getTargetJobTitle():"No target role"%></div>
                </div>
                <span class="score-badge <%=sc%>"><%=st%></span>
            </div>
            <div class="card-meta"><%=r.getFirstName()%> <%=r.getLastName()%> &nbsp;·&nbsp; ID #<%=r.getId()%></div>
            <div class="tags">
                <span class="tag">Personal</span>
                <% if(r.getProfessionalSummary()!=null&&!r.getProfessionalSummary().isEmpty()){%><span class="tag">Summary</span><%}%>
                <span class="tag">Education</span><span class="tag">Skills</span>
            </div>
            <div class="actions">
                <a href="viewResume?id=<%=r.getId()%>" class="abtn abtn-view">View</a>
                <a href="atsAnalysis?resumeId=<%=r.getId()%>" class="abtn abtn-analyze">Analyze</a>
                <button class="abtn abtn-delete" onclick="confirmDelete(<%=r.getId()%>)">Delete</button>
            </div>
        </div>
    <% } } %>
    </div>
</main>
</div>
<script>
function filterCards(){
    var q=document.getElementById('searchInput').value.toLowerCase();
    document.querySelectorAll('.card').forEach(function(c){
        c.style.display=c.dataset.title.includes(q)?'':'none';
    });
}
function confirmDelete(id){
    if(confirm('Delete this resume? This cannot be undone.')){
        window.location.href='deleteResume?id='+id;
    }
}
</script>
</body></html>
