<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html><html><head><title>Forgot Password - ATSCV</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:"Segoe UI",Arial,sans-serif;}
body{min-height:100vh;background:radial-gradient(circle at top left,rgba(59,130,246,0.22),transparent 30%),linear-gradient(135deg,#0f172a,#111827,#1e293b);display:flex;align-items:center;justify-content:center;padding:30px;color:#fff;}
.card{width:100%;max-width:460px;background:rgba(15,23,42,0.94);border:1px solid rgba(148,163,184,0.12);border-radius:24px;padding:44px 38px;box-shadow:0 24px 50px rgba(0,0,0,0.4);}
.badge{display:inline-block;padding:7px 14px;border-radius:999px;background:rgba(59,130,246,0.15);border:1px solid rgba(96,165,250,0.28);color:#93c5fd;font-size:12px;font-weight:700;letter-spacing:1px;margin-bottom:22px;}
h2{font-size:28px;margin-bottom:10px;}
.subtitle{color:#94a3b8;font-size:14px;line-height:1.6;margin-bottom:28px;}
.steps{display:flex;gap:8px;margin-bottom:28px;}
.step{flex:1;height:4px;border-radius:4px;background:rgba(255,255,255,0.1);}
.step.active{background:linear-gradient(90deg,#2563eb,#60a5fa);}
.info-box{background:rgba(59,130,246,0.09);border:1px solid rgba(59,130,246,0.22);border-radius:12px;padding:14px 16px;color:#93c5fd;font-size:13px;line-height:1.6;margin-bottom:24px;}
.success-box{background:rgba(34,197,94,0.10);border:1px solid rgba(34,197,94,0.28);border-radius:12px;padding:14px 16px;color:#86efac;font-size:14px;line-height:1.6;margin-bottom:20px;}
.form-group{margin-bottom:20px;}
.form-group label{display:block;font-size:14px;font-weight:600;color:#e2e8f0;margin-bottom:8px;}
.form-group input{width:100%;padding:14px 15px;border-radius:14px;border:1px solid #334155;background:#0f172a;color:white;font-size:14px;outline:none;transition:all 0.25s;}
.form-group input:focus{border-color:#3b82f6;box-shadow:0 0 0 4px rgba(59,130,246,0.14);}
.btn{width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,#2563eb,#3b82f6);color:white;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 10px 20px rgba(37,99,235,0.28);font-family:inherit;}
.btn:hover{opacity:0.9;}
.err{color:#fca5a5;font-size:13px;text-align:center;margin-top:12px;min-height:20px;}
.back-link{text-align:center;margin-top:20px;font-size:14px;color:#94a3b8;}
.back-link a{color:#60a5fa;font-weight:700;}
</style></head>
<body>
<div class="card">
    <div class="badge">ATS CV BUILDER</div>
    <div class="steps">
        <div class="step active" id="s1"></div>
        <div class="step" id="s2"></div>
        <div class="step" id="s3"></div>
    </div>
    <div id="stepEmail">
        <h2>Forgot Password</h2>
        <p class="subtitle">Enter your registered email and we will send you a reset link.</p>
        <div class="info-box">ℹ️ Password reset emails are sent to your registered address. Check your spam folder if you do not see it.</div>
        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" placeholder="Enter your registered email" required>
        </div>
        <button class="btn" onclick="submitEmail()">Send Reset Link</button>
        <div class="err" id="emailError"></div>
    </div>
    <div id="stepSent" style="display:none">
        <h2>Check Your Email</h2>
        <p class="subtitle">We have sent a password reset link to your email address.</p>
        <div class="success-box">✅ A reset link has been sent. Please check your inbox and spam folder.</div>
        <p style="color:#94a3b8;font-size:14px;line-height:1.7;margin-bottom:24px">The link will expire in 30 minutes. If you did not receive it, you can request a new one below.</p>
        <button class="btn" onclick="resend()">Resend Email</button>
        <div id="resendMsg" style="color:#86efac;font-size:13px;text-align:center;margin-top:10px;display:none">✅ Email resent successfully.</div>
    </div>
    <div class="back-link"><a href="login.jsp">← Back to Login</a></div>
</div>
<script>
function submitEmail(){
    var e=document.getElementById('email').value.trim();
    var err=document.getElementById('emailError');
    if(!e||!e.includes('@')){err.textContent='Please enter a valid email address.';return;}
    err.textContent='';
    document.getElementById('s2').classList.add('active');
    document.getElementById('stepEmail').style.display='none';
    document.getElementById('stepSent').style.display='block';
}
function resend(){document.getElementById('resendMsg').style.display='block';}
</script>
</body></html>
