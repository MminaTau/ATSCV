<%@ page import="com.example.atscv.model.User" %>
<%@ page import="com.example.atscv.dao.ResumeDAO" %>
<%@ page import="com.example.atscv.model.Resume" %>
<%@ page import="java.util.List" %>
<%@ page session="true" %>
<%@ page contentType="text/html;charset=UTF-8" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null) { response.sendRedirect("login.jsp"); return; }
    ResumeDAO rDao = new ResumeDAO();
    List<Resume> resumes = rDao.getResumesByUserId(user.getId());
    int totalCVs = resumes != null ? resumes.size() : 0;
    double bestScore = 0;
    if (resumes != null) for (Resume r : resumes) if (r.getAtsScore() > bestScore) bestScore = r.getAtsScore();
    String scoreDisplay = bestScore > 0 ? (int)bestScore + "%" : "--";
    String profileStatus = totalCVs > 0 ? "Active" : "New";
%>
<!DOCTYPE html><html><head><title>Dashboard - ATSCV</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:"Segoe UI",Arial,sans-serif;}
body{background:radial-gradient(circle at top left,rgba(59,130,246,0.15),transparent 25%),linear-gradient(135deg,#0f172a,#111827 45%,#1e293b 100%);color:#fff;min-height:100vh;}
a{text-decoration:none;color:inherit;}
.layout{display:grid;grid-template-columns:260px 1fr;min-height:100vh;}
.sidebar{background:rgba(15,23,42,0.95);border-right:1px solid rgba(148,163,184,0.12);padding:28px 20px;}
.brand{display:inline-block;padding:8px 14px;border-radius:999px;background:rgba(59,130,246,0.15);border:1px solid rgba(96,165,250,0.28);color:#93c5fd;font-size:12px;font-weight:700;letter-spacing:1px;margin-bottom:26px;}
.user-box{background:rgba(30,41,59,0.78);border:1px solid rgba(148,163,184,0.12);border-radius:18px;padding:18px;margin-bottom:24px;}
.user-box h3{font-size:17px;margin-bottom:4px;}
.user-box p{color:#94a3b8;font-size:13px;word-break:break-word;}
.menu-title{font-size:12px;letter-spacing:1px;text-transform:uppercase;color:#64748b;margin-bottom:12px;padding-left:6px;}
.menu{display:grid;gap:8px;}
.menu a{display:block;color:#e2e8f0;background:rgba(30,41,59,0.65);border:1px solid rgba(148,163,184,0.10);padding:13px 16px;border-radius:14px;font-size:14px;font-weight:600;transition:all 0.2s;}
.menu a:hover,.menu a.active{background:linear-gradient(135deg,rgba(37,99,235,0.28),rgba(59,130,246,0.22));border-color:rgba(96,165,250,0.35);transform:translateX(2px);}
.main{padding:30px;}
.topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:28px;}
.topbar h1{font-size:30px;margin-bottom:6px;}
.topbar p{color:#94a3b8;font-size:14px;}
.logout-btn{color:white;background:linear-gradient(135deg,#dc2626,#ef4444);padding:12px 18px;border-radius:12px;font-size:14px;font-weight:700;box-shadow:0 10px 20px rgba(239,68,68,0.22);}
.hero{background:linear-gradient(135deg,rgba(37,99,235,0.22),rgba(30,41,59,0.82));border:1px solid rgba(96,165,250,0.18);border-radius:24px;padding:30px;margin-bottom:24px;}
.hero h2{font-size:26px;margin-bottom:10px;}
.hero p{color:#cbd5e1;font-size:15px;line-height:1.7;}
.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin-bottom:26px;}
.stat{background:rgba(15,23,42,0.82);border:1px solid rgba(148,163,184,0.12);border-radius:20px;padding:22px;}
.stat .lbl{color:#94a3b8;font-size:13px;margin-bottom:8px;}
.stat .val{font-size:30px;font-weight:800;margin-bottom:6px;}
.stat .hint{color:#cbd5e1;font-size:13px;line-height:1.5;}
.grid2{display:grid;grid-template-columns:1.2fr 0.8fr;gap:20px;}
.panel{background:rgba(15,23,42,0.84);border:1px solid rgba(148,163,184,0.12);border-radius:22px;padding:24px;}
.panel h3{font-size:20px;margin-bottom:8px;}
.panel .sub{color:#94a3b8;font-size:14px;margin-bottom:20px;line-height:1.6;}
.action-card{display:block;background:rgba(30,41,59,0.75);border:1px solid rgba(148,163,184,0.10);border-radius:16px;padding:18px;margin-bottom:14px;transition:all 0.2s;}
.action-card:hover{transform:translateY(-2px);border-color:rgba(96,165,250,0.28);background:rgba(37,99,235,0.12);}
.action-card h4{color:#f8fafc;font-size:16px;margin-bottom:6px;}
.action-card p{color:#94a3b8;font-size:14px;line-height:1.6;}
.prog-item{background:rgba(30,41,59,0.7);border-radius:16px;padding:16px;border:1px solid rgba(148,163,184,0.10);margin-bottom:14px;}
.prog-title{display:flex;justify-content:space-between;font-size:14px;margin-bottom:10px;color:#e2e8f0;}
.bar{height:10px;background:#1e293b;border-radius:999px;overflow:hidden;margin-bottom:8px;}
.fill{height:100%;border-radius:999px;background:linear-gradient(135deg,#2563eb,#60a5fa);}
.prog-item p{color:#94a3b8;font-size:13px;line-height:1.5;}
@media(max-width:900px){.layout{grid-template-columns:1fr}.sidebar{display:none}.stats,.grid2{grid-template-columns:1fr}}
</style></head>
<body>
<div class="layout">
<aside class="sidebar">
    <div class="brand">ATS CV BUILDER</div>
    <div class="user-box">
        <h3><%=user.getFullName()%></h3>
        <p><%=user.getEmail()%></p>
    </div>
    <div class="menu-title">Navigation</div>
    <nav class="menu">
        <a href="dashboard.jsp" class="active">Dashboard</a>
        <a href="buildCV">Build CV</a>
        <a href="myResumes">My Resumes</a>
        <a href="atsAnalysis">ATS Analysis</a>
        <a href="results">Results</a>
        <a href="profile">Profile</a>
        <a href="logout">Logout</a>
    </nav>
</aside>
<main class="main">
    <div class="topbar">
        <div>
            <h1>Welcome back, <%=user.getFullName()%></h1>
            <p>Manage your CV, run ATS checks, and improve your application strength.</p>
        </div>
        <a href="logout" class="logout-btn">Logout</a>
    </div>
    <div class="hero">
        <h2>Your ATS career toolkit starts here.</h2>
        <p>Build professional CVs, compare them against job descriptions, discover missing keywords, and improve your chances of passing applicant tracking systems used by employers.</p>
    </div>
    <div class="stats">
        <div class="stat">
            <div class="lbl">Saved CVs</div>
            <div class="val"><%=totalCVs%></div>
            <div class="hint"><%=totalCVs==0?"Build your first CV to get started.":"Click My Resumes to view them all."%></div>
        </div>
        <div class="stat">
            <div class="lbl">Best ATS Score</div>
            <div class="val"><%=scoreDisplay%></div>
            <div class="hint"><%=bestScore>0?"Your top performing resume score.":"Run an ATS analysis to get a score."%></div>
        </div>
        <div class="stat">
            <div class="lbl">Profile Status</div>
            <div class="val"><%=profileStatus%></div>
            <div class="hint"><%=totalCVs>0?"Your account is active and ready.":"Complete your CV to activate."%></div>
        </div>
    </div>
    <div class="grid2">
        <div class="panel">
            <h3>Quick Actions</h3>
            <p class="sub">Jump straight into the main features.</p>
            <a href="buildCV" class="action-card">
                <h4>Build Your CV</h4>
                <p>Create and structure your ATS-friendly CV with all the right sections.</p>
            </a>
            <a href="atsAnalysis" class="action-card">
                <h4>Analyze Against Job Description</h4>
                <p>Paste a job description and identify missing keywords instantly.</p>
            </a>
            <a href="myResumes" class="action-card">
                <h4>View My Resumes</h4>
                <p>Browse, view, and manage all your saved CVs in one place.</p>
            </a>
        </div>
        <div class="panel">
            <h3>Progress Overview</h3>
            <p class="sub">Track your ATS optimization journey.</p>
            <div class="prog-item">
                <div class="prog-title"><span>Account Setup</span><span>100%</span></div>
                <div class="bar"><div class="fill" style="width:100%"></div></div>
                <p>Registration, login and dashboard are all working.</p>
            </div>
            <div class="prog-item">
                <div class="prog-title"><span>CV Builder</span><span><%=totalCVs>0?"100%":"0%"%></span></div>
                <div class="bar"><div class="fill" style="width:<%=totalCVs>0?100:0%>%"></div></div>
                <p><%=totalCVs>0?totalCVs+" resume(s) saved.":"Build your first CV to get started."%></p>
            </div>
            <div class="prog-item">
                <div class="prog-title"><span>ATS Analysis</span><span><%=bestScore>0?"100%":"0%"%></span></div>
                <div class="bar"><div class="fill" style="width:<%=(int)bestScore%>%"></div></div>
                <p><%=bestScore>0?"Best score: "+(int)bestScore+"%. Keep optimizing!":"Run your first ATS analysis to get a score."%></p>
            </div>
        </div>
    </div>
</main>
</div>
</body></html>
