<%@ page import="com.example.atscv.model.User,com.example.atscv.model.Resume,com.example.atscv.dao.ResumeDAO,java.util.List" %>
<%@ page session="true" contentType="text/html;charset=UTF-8" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null) { response.sendRedirect("login.jsp"); return; }
    List<Resume> resumes = new ResumeDAO().getResumesByUserId(user.getId());
    String atsScore = (String) request.getAttribute("atsScore");
    String analysisResult = (String) request.getAttribute("analysisResult");
    String matchedKeywords = (String) request.getAttribute("matchedKeywords");
    String missingKeywords = (String) request.getAttribute("missingKeywords");
    String errorMessage = (String) request.getAttribute("errorMessage");
    Object selId = request.getAttribute("selectedResumeId");
    int selectedResumeId = selId != null ? (int)selId : 0;
%>
<!DOCTYPE html><html><head><title>ATS Analysis - ATSCV</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:"Segoe UI",Arial,sans-serif;}
body{background:linear-gradient(135deg,#020817,#06122f,#0f172a);color:#fff;min-height:100vh;}
a{text-decoration:none;color:inherit;}
.layout{display:grid;grid-template-columns:260px 1fr;min-height:100vh;}
.sidebar{background:rgba(15,23,42,0.95);border-right:1px solid rgba(148,163,184,0.12);padding:28px 20px;}
.brand{display:inline-block;padding:8px 14px;border-radius:999px;background:rgba(59,130,246,0.15);border:1px solid rgba(96,165,250,0.28);color:#93c5fd;font-size:12px;font-weight:700;letter-spacing:1px;margin-bottom:26px;}
.user-box{background:rgba(30,41,59,0.78);border:1px solid rgba(148,163,184,0.12);border-radius:18px;padding:16px;margin-bottom:24px;}
.user-box h3{font-size:16px;margin-bottom:4px;}.user-box p{color:#94a3b8;font-size:13px;}
.menu{display:grid;gap:8px;}
.menu a{display:block;color:#e2e8f0;background:rgba(30,41,59,0.65);border:1px solid rgba(148,163,184,0.10);padding:13px 16px;border-radius:14px;font-size:14px;font-weight:600;transition:all 0.2s;}
.menu a:hover,.menu a.active{background:linear-gradient(135deg,rgba(37,99,235,0.28),rgba(59,130,246,0.22));border-color:rgba(96,165,250,0.35);}
.main{padding:32px;}
.topbar{margin-bottom:28px;}.topbar h1{font-size:28px;font-weight:800;}.topbar p{color:#94a3b8;font-size:14px;margin-top:4px;}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:20px;}
.panel{background:rgba(15,23,42,0.84);border:1px solid rgba(148,163,184,0.12);border-radius:22px;padding:24px;margin-bottom:20px;}
.panel h3{font-size:18px;margin-bottom:6px;}.panel .sub{color:#94a3b8;font-size:13px;margin-bottom:18px;line-height:1.6;}
.field{margin-bottom:16px;}
.field label{display:block;font-size:12px;font-weight:700;color:#a5b4fc;letter-spacing:0.8px;text-transform:uppercase;margin-bottom:8px;}
.field select,.field textarea{width:100%;background:#16233f;border:1px solid rgba(255,255,255,0.07);color:#fff;border-radius:14px;padding:13px 14px;font-size:14px;outline:none;}
.field textarea{min-height:200px;resize:vertical;}.field select{cursor:pointer;}
.analyze-btn{width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,#2563eb,#3b82f6);color:white;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 10px 20px rgba(37,99,235,0.28);}
.analyze-btn:hover{opacity:0.9;}
.alert-err{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:#fca5a5;padding:14px;border-radius:14px;margin-bottom:20px;}
.score-circle-wrap{display:flex;align-items:center;gap:28px;margin-bottom:24px;}
.score-ring{width:150px;height:150px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;position:relative;}
.score-inner{width:110px;height:110px;border-radius:50%;background:rgba(15,23,42,0.95);display:flex;flex-direction:column;align-items:center;justify-content:center;}
.score-num{font-size:32px;font-weight:800;}.score-lbl{color:#94a3b8;font-size:12px;}
.result-text{font-size:15px;line-height:1.7;color:#cbd5e1;}
.kw-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.kw-box{background:rgba(30,41,59,0.7);border-radius:14px;padding:16px;}
.kw-box h4{font-size:14px;margin-bottom:12px;}
.kw-matched{color:#86efac;}.kw-missing{color:#fca5a5;}
.kw-tags{display:flex;flex-wrap:wrap;gap:7px;}
.kw-tag{padding:5px 12px;border-radius:999px;font-size:12px;font-weight:600;}
.kw-tag.matched{background:rgba(34,197,94,0.12);color:#86efac;border:1px solid rgba(34,197,94,0.25);}
.kw-tag.missing{background:rgba(239,68,68,0.1);color:#fca5a5;border:1px solid rgba(239,68,68,0.2);}
.tips{display:grid;gap:10px;}
.tip{display:flex;gap:12px;background:rgba(30,41,59,0.7);border-radius:14px;padding:14px;}
.tip-icon{font-size:18px;flex-shrink:0;}.tip-text{font-size:14px;color:#cbd5e1;line-height:1.6;}
@media(max-width:900px){.layout{grid-template-columns:1fr}.sidebar{display:none}.grid2{grid-template-columns:1fr}}
</style></head>
<body>
<div class="layout">
<aside class="sidebar">
    <div class="brand">ATS CV BUILDER</div>
    <div class="user-box"><h3><%=user.getFullName()%></h3><p><%=user.getEmail()%></p></div>
    <nav class="menu">
        <a href="dashboard.jsp">Dashboard</a><a href="buildCV">Build CV</a>
        <a href="myResumes">My Resumes</a><a href="atsAnalysis" class="active">ATS Analysis</a>
        <a href="results">Results</a><a href="profile">Profile</a><a href="logout">Logout</a>
    </nav>
</aside>
<main class="main">
    <div class="topbar"><h1>ATS Analysis</h1><p>Compare your CV against a job description to get your compatibility score.</p></div>
    <% if(errorMessage!=null){%><div class="alert-err"><%=errorMessage%></div><%}%>
    <form action="atsAnalysis" method="post">
    <div class="grid2">
        <div class="panel">
            <h3>Select Resume</h3><p class="sub">Choose which saved CV to analyze.</p>
            <div class="field"><label>Resume</label>
            <select name="resumeId" required>
                <option value="">-- Select a Resume --</option>
                <% if(resumes!=null){for(Resume r:resumes){%>
                <option value="<%=r.getId()%>" <%=r.getId()==selectedResumeId?"selected":""%>>
                    <%=r.getResumeTitle()%> — <%=r.getTargetJobTitle()!=null?r.getTargetJobTitle():"No role"%>
                </option>
                <%}}%>
            </select></div>
            <% if(resumes==null||resumes.isEmpty()){%>
            <p style="color:#fca5a5;font-size:13px;">No resumes found. <a href="buildCV" style="color:#60a5fa;">Build one first →</a></p>
            <%}%>
        </div>
        <div class="panel">
            <h3>Job Description</h3><p class="sub">Paste the full job posting you want to apply for.</p>
            <div class="field"><label>Job Description</label>
            <textarea name="jobDescription" placeholder="Paste the full job description here including requirements, responsibilities and skills..." required></textarea></div>
        </div>
    </div>
    <div class="panel"><button type="submit" class="analyze-btn">🔍 Run ATS Analysis</button></div>
    </form>

    <% if(atsScore!=null){ int score=Integer.parseInt(atsScore);
       String ringColor = score>=75?"#22c55e":score>=50?"#eab308":"#ef4444";
       int angle = (int)(score*3.6); %>
    <div class="panel">
        <h3>Analysis Results</h3><p class="sub">How your CV performs against the job description.</p>
        <div class="score-circle-wrap">
            <div class="score-ring" style="background:conic-gradient(<%=ringColor%> <%=angle%>deg, rgba(255,255,255,0.07) 0)">
                <div class="score-inner">
                    <span class="score-num"><%=score%>%</span>
                    <span class="score-lbl">ATS Score</span>
                </div>
            </div>
            <p class="result-text"><%=analysisResult%></p>
        </div>
        <div class="kw-grid">
            <div class="kw-box">
                <h4 class="kw-matched">✅ Matched Keywords</h4>
                <div class="kw-tags">
                    <% if(matchedKeywords!=null&&!matchedKeywords.isEmpty()){for(String kw:matchedKeywords.split(",")){%>
                    <span class="kw-tag matched"><%=kw.trim()%></span>
                    <%}}else{%><span style="color:#64748b;font-size:13px;">None matched</span><%}%>
                </div>
            </div>
            <div class="kw-box">
                <h4 class="kw-missing">❌ Missing Keywords</h4>
                <div class="kw-tags">
                    <% if(missingKeywords!=null&&!missingKeywords.isEmpty()){for(String kw:missingKeywords.split(",")){%>
                    <span class="kw-tag missing"><%=kw.trim()%></span>
                    <%}}else{%><span style="color:#64748b;font-size:13px;">None missing — great job!</span><%}%>
                </div>
            </div>
        </div>
    </div>
    <div class="panel">
        <h3>Improvement Tips</h3><p class="sub">Apply these to increase your score.</p>
        <div class="tips">
            <div class="tip"><span class="tip-icon">🎯</span><span class="tip-text">Add the missing keywords naturally into your skills and experience sections.</span></div>
            <div class="tip"><span class="tip-icon">📋</span><span class="tip-text">Mirror the exact job title from the posting in your resume title and summary.</span></div>
            <div class="tip"><span class="tip-icon">📊</span><span class="tip-text">Quantify achievements with numbers — percentages, timeframes, team sizes.</span></div>
            <div class="tip"><span class="tip-icon">🔤</span><span class="tip-text">Avoid tables, images, or columns — ATS systems struggle to parse them.</span></div>
        </div>
    </div>
    <%}%>
</main>
</div>
</body></html>
